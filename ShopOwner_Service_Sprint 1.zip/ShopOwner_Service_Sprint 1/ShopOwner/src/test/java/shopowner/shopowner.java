package shopowner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class shopowner {

	@Test
	void contextLoads() {
	}

}
