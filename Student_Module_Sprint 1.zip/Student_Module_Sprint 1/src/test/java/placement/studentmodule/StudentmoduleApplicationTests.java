package placement.studentmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
